#include <stdint.h>

__asm uint32_t gcd(uint32_t a, uint32_t b){
    NOP
    BX lr
}
    
int main(void){
    volatile uint32_t x, y, z;

    x = gcd(30, 21);
    y = gcd(100, 625);
    z = gcd(13, 15);

    while (1);
}

