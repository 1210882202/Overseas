#include <stdint.h>
#include <stdio.h>
#include "i2c.h"

int main(void) {
	uint8_t buf_in[16], buf_out[16] = "Hello World.";
    
    i2c_init();
   
    i2c_write(0x25, buf_out, 4);
    i2c_read(0x25, buf_in, 2);
	
	while (1);
}

// *******************************ARM University Program Copyright � ARM Ltd 2016*************************************   
