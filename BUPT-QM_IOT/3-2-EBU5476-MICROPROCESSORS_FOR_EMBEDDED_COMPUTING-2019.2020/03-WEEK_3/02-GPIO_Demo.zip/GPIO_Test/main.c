#include "stm32f10x.h"
#include "platform.h"
#include "gpio.h"

int main(void){
    volatile int p, q;
    gpio_set_mode(PA_0, Output);
    gpio_set_mode(PA_1, PullUp);
    gpio_set_mode(PB_0, PullDown);
    gpio_set_mode(PB_7, Output);
    gpio_set_mode(PA_15, Output);
    gpio_set(PB_7, PIN_LOW);
    
    while (1){
        p = gpio_get(PA_13);
        q = gpio_get(PA_14);
        gpio_set(PA_15, q);
        if (p == PIN_HIGH && q == PIN_HIGH)
            gpio_set(PA_0, PIN_HIGH);
        else
            gpio_set(PA_0, PIN_LOW);
        if ((q = gpio_get_range(PA_2, 4)) == 0xF){
            gpio_toggle(PB_7);
        }
    }
}
